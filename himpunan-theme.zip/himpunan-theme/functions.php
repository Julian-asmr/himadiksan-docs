
<?php
function himpunan_enqueue_styles() {
    wp_enqueue_style('himpunan-style', get_stylesheet_uri());
}
add_action('wp_enqueue_scripts', 'himpunan_enqueue_styles');
?>
