
<?php get_header(); ?>
<main class="container">
    <h2>Selamat Datang</h2>
    <p>Website resmi himpunan mahasiswa.</p>
</main>
<?php get_footer(); ?>
