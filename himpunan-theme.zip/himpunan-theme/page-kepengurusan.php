<?php
/**
 * Template: Kepengurusan
 * Template Name: Kepengurusan
 * Digunakan untuk halaman Kepengurusan.
 */
get_header();
?>

<main class="main-content">
    <div class="container">
        <h1 class="page-title"><?php the_title(); ?></h1>
        
        <section class="content-section">
            <h2>Struktur Organisasi</h2>
            <div class="entry-content">
                <?php the_content(); // Konten dari editor blok, bisa gunakan gambar struktur ?>
            </div>
        </section>
        
        <section class="content-section">
            <h2>Daftar Jabatan Pengurus</h2>
            <ul>
                <?php
                // Contoh daftar jabatan (bisa diganti dengan custom fields atau ACF jika diperlukan, tapi tanpa plugin)
                $jabatan = array(
                    'Ketua' => 'Nama Ketua',
                    'Wakil Ketua' => 'Nama Wakil Ketua',
                    'Sekretaris' => 'Nama Sekretaris',
                    // Tambahkan lebih banyak sesuai kebutuhan
                );
                foreach ($jabatan as $posisi => $nama) {
                    echo '<li><strong>' . $posisi . ':</strong> ' . $nama . '</li>';
                }
                ?>
            </ul>
        </section>
    </div>
</main>

<?php get_footer(); ?>
